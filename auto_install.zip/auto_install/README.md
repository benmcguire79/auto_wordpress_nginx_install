# Ubuntu-16.04-Nginx-WordPress-Autoinstall-Bash-Script
Ubuntu 16.04 Nginx extras, Percona MySQL 5.7, PHP 7, WordPress Autoinstall Bash Script
